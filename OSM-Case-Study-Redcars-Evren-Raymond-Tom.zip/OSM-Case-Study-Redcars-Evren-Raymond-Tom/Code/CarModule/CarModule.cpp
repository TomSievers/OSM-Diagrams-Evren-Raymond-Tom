#include "CarModule.hpp"
CarModule::CarModule(/* args */)
{
}

CarModule::~CarModule()
{
}
