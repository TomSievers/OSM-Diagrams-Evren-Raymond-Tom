#include "AdminApp.hpp"
AdminApplication::AdminApplication(/* args */){}
AdminApplication::~AdminApplication(){}
bool AdminApplication::editUser(DataTypes::User& updatedUser){}
short AdminApplication::mainThread(){}
bool AdminApplication::creatAdmin(std::string& username, std::string& password){}
bool AdminApplication::editCar(DataTypes::CarDetails& updatedCar){}