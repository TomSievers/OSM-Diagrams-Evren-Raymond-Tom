#ifndef POSITION_HPP
#define POSITION_HPP
typedef struct Position
{
    double longitude = 0, latitude = 0, altitude = 0;
};
#endif // !POSITION_HPP

