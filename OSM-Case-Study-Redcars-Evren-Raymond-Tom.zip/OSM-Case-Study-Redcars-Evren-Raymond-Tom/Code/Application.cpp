#include "Application.hpp"

Application::Application(/* args */)
{
}

Application::~Application()
{
}