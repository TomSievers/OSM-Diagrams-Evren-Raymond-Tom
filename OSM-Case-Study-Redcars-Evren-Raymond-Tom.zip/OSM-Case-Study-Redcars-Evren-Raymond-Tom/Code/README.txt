To compile everything execute the command "make" on the commandline in this directory.

These applications and dlls can only be compiled on a Windows system with an inscdtalation of MinGW.