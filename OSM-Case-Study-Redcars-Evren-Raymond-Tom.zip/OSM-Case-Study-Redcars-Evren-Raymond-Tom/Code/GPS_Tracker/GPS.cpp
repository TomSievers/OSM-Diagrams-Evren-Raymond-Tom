#include "GPS.hpp"
#include <iostream>
IPositional::IPositional()
{
}

IPositional::~IPositional()
{
}

GPS::GPS(/* args */)
{
}

GPS::~GPS()
{
}

Position GPS::getPosition()
{
}