#include "Pole.hpp"

Pole::Pole(/* args */)
{
}

Pole::~Pole()
{
}
