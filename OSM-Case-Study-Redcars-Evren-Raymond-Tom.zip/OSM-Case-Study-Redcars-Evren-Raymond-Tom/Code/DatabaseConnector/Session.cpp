#include "Session.hpp"

ull_t Session::getSessionId()
{
}

Session::Session()
{
}

Session::~Session()
{
}
